from th8_agent.nodes.qc import qc_spec_check

def test_qc_fail():
    out = qc_spec_check({"payload": {"moisture": 4.2, "spec_limit": 4.0}})
    assert out["output"]["result"] == "FAIL"

def test_qc_pass():
    out = qc_spec_check({"payload": {"moisture": 3.9, "spec_limit": 4.0}})
    assert out["output"]["result"] == "PASS"
