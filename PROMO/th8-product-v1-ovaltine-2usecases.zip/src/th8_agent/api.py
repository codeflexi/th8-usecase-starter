from fastapi import FastAPI, Body
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from dotenv import load_dotenv
import os

from th8_agent.graphs.ovaltine_graph import build_graph
from th8_agent.utils.llm_factory import build_models
from th8_agent.utils.logging import setup_logging
from th8_agent.utils.pii import redact_payload

load_dotenv()
setup_logging()

app = FastAPI(title="TH8 Product v1 API", version="1.0")

# Serve UI mockups
app.mount("/ui", StaticFiles(directory="ui"), name="ui")

@app.get("/")
def root_redirect():
    return RedirectResponse(url="/ui/index.html")


graph = build_graph()
models = build_models()

class RunRequest(BaseModel):
    task_type: str
    payload: dict

@app.post("/run")
def run(req: RunRequest):
    # PII redaction
    clean_payload, audit = redact_payload(req.payload)

    state = {
        "task_type": req.task_type,
        "payload": clean_payload,
        "models": {"slm": models.slm, "llm": models.llm, "fallback": models.fallback},
        "model_names": {
            "slm": os.getenv("SLM_MODEL"),
            "llm": os.getenv("LLM_MODEL"),
            "fallback": os.getenv("FALLBACK_MODEL"),
        },
    }

    result = graph.invoke(state)
    return {
        "result": result.get("output", result),
        "pii_audit": audit,
    }


@app.get('/demo/complaint')
def demo_complaint():
    return {
        'task_type':'complaint_pipeline',
        'payload':{
            'complaint_id':'C-0001','channel':'Facebook','product_code':'OVALTIN-ORIGINAL','period':'2025-12',
            'text':'กลิ่นแปลก เหมือนหืน เปิดแล้วไม่มั่นใจให้ลูกดื่ม'
        }
    }

@app.get('/demo/fpa')
def demo_fpa():
    return {
        'task_type':'fpa_pipeline',
        'payload':{'period':'2025-11','metric':'net_sales'}
    }
