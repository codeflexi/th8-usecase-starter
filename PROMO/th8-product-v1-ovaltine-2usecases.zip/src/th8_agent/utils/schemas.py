from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, ValidationError, field_validator

class QcCheckOutput(BaseModel):
    result: str = Field(..., pattern="^(PASS|FAIL)$")
    reason: str

class BatchRow(BaseModel):
    batch_id: str
    date: str
    yield_pct: float
    moisture: float
    qc_status: str
    supplier: str
    line: str

class BatchFilterOutput(BaseModel):
    criteria: Dict[str, Any]
    rows: List[BatchRow]
    row_count: int

class DeviationClassification(BaseModel):
    type: str
    severity: str
    confidence: float
    rationale: str

    @field_validator("confidence")
    @classmethod
    def conf_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError("confidence must be in [0,1]")
        return v

class RootCauseOutput(BaseModel):
    hypotheses: List[Dict[str, Any]]
    checks: List[str]
    immediate_actions: List[str]

class ExecSummaryOutput(BaseModel):
    summary: str

def parse_json_strict(text: str) -> Dict[str, Any]:
    # Best-effort strict JSON parsing (no code fences)
    text = text.strip()
    if text.startswith("```"):
        # remove fences
        text = text.strip("`")
        text = text.replace("json", "", 1).strip()
    return json_loads(text)

def json_loads(s: str) -> Dict[str, Any]:
    import json
    return json.loads(s)


from pydantic import BaseModel, Field
from typing import List, Literal, Optional, Dict

class ComplaintTriage(BaseModel):
    category: Literal["taste","smell","packaging","health","availability","other"]
    severity: Literal["low","medium","high"]
    confidence: float = Field(ge=0.0, le=1.0)
    rationale: str
    recommended_action: Literal["reply_standard","request_more_info","escalate_qa","escalate_legal","monitor"]
    pii_detected: bool = False

class ComplaintEvidencePack(BaseModel):
    complaint_id: str
    channel: str
    product_code: str
    period: str
    similar_cases_90d: int
    top_similar_category: str
    notes: str

class FPAVarianceExplain(BaseModel):
    period: str
    metric: Literal["net_sales","volume","cogs","gross_margin"]
    variance_value: float
    variance_pct: float
    drivers: List[Dict[str, str]]  # [{"driver":"promo_uplift","evidence":"..."}]
    recommended_actions: List[Dict[str, str]]  # [{"action":"...","owner":"...","due":"..."}]
    confidence: float = Field(ge=0.0, le=1.0)

class ExecutiveBrief(BaseModel):
    period: str
    key_points: List[str]
    risks: List[str]
    actions_next_7d: List[str]
