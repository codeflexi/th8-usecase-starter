import json
import os
import time
from pathlib import Path
from typing import Any, Dict, Optional

METRICS_PATH = os.getenv("METRICS_PATH", "./data/metrics.jsonl")

def _now_ms() -> int:
    return int(time.time() * 1000)

def record_metric(event: str, payload: Dict[str, Any]) -> None:
    path = Path(METRICS_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    row = {"ts_ms": _now_ms(), "event": event, **payload}
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
