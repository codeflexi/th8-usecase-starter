import re
from typing import Dict, Any, Tuple, List

# Simple, extensible PII patterns (demo-safe)
PATTERNS = {
    "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "phone": re.compile(r"(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,3}\)?[\s-]?)?\d{3}[\s-]?\d{4}"),
    "id": re.compile(r"\b\d{13}\b"),  # Thai national ID (example)
}

def redact_text(text: str, *, mask: str = "[REDACTED]") -> Tuple[str, List[Dict[str, Any]]]:
    audit = []
    redacted = text
    for name, pat in PATTERNS.items():
        for m in pat.finditer(redacted):
            audit.append({
                "field": "text",
                "pii_type": name,
                "start": m.start(),
                "end": m.end(),
                "original_len": m.end() - m.start(),
            })
        redacted = pat.sub(mask, redacted)
    return redacted, audit

def redact_payload(payload: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    out = {}
    audit_all: List[Dict[str, Any]] = []
    for k, v in payload.items():
        if isinstance(v, str):
            r, a = redact_text(v)
            out[k] = r
            for x in a:
                x["field"] = k
            audit_all.extend(a)
        else:
            out[k] = v
    return out, audit_all
