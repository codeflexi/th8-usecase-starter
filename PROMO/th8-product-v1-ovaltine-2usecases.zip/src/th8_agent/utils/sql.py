import os
import sqlite3
from typing import Any, Dict, Tuple, Optional

from th8_agent.utils.tool_policy import assert_tool_allowed

DB_PATH = os.getenv("DB_PATH", "./data/ovantin.db")

def run_sql(query: str, params: Tuple[Any, ...] = (), *, task_type: Optional[str] = None) -> Dict[str, Any]:
    # Tool permission gate
    if task_type is not None:
        assert_tool_allowed(task_type, "sql")

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    conn.close()
    return {"rows": [dict(r) for r in rows], "row_count": len(rows)}
