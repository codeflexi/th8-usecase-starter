from dataclasses import dataclass
from typing import Dict, List, Literal

TaskType = Literal["qc_check", "batch_filter", "root_cause", "exec_summary", "deviation_classify"]

@dataclass(frozen=True)
class ToolPolicy:
    allowed_tools: List[str]

# Allow-list per task. Extend as you add tools (erp_api, s3, etc.)
POLICY: Dict[TaskType, ToolPolicy] = {
    "qc_check": ToolPolicy(allowed_tools=[]),
    "batch_filter": ToolPolicy(allowed_tools=["sql"]),
    "root_cause": ToolPolicy(allowed_tools=["sql"]),  # optional context lookups
    "exec_summary": ToolPolicy(allowed_tools=["sql"]),
    "deviation_classify": ToolPolicy(allowed_tools=[]),
}

def assert_tool_allowed(task_type: str, tool_name: str) -> None:
    pol = POLICY.get(task_type)
    if pol is None or tool_name not in pol.allowed_tools:
        raise PermissionError(f"Tool '{tool_name}' not allowed for task '{task_type}'")
