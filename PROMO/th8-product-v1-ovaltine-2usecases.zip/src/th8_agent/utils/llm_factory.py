import os
import time
import logging
from dataclasses import dataclass

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

try:
    from langchain_openai import ChatOpenAI
except Exception:
    ChatOpenAI = None  # type: ignore

log = logging.getLogger("th8.llm")

from th8_agent.utils.metrics import record_metric

class LLMProviderError(RuntimeError):
    pass

@dataclass
class ModelBundle:
    slm: object
    llm: object
    fallback: object

def _require_openai():
    if ChatOpenAI is None:
        raise LLMProviderError(
            "langchain-openai not available. Install requirements.txt or adapt llm_factory.py for your provider."
        )

def build_models() -> ModelBundle:
    _require_openai()
    llm_model = os.getenv("LLM_MODEL", "gpt-4o-mini")
    slm_model = os.getenv("SLM_MODEL", llm_model)
    fallback_model = os.getenv("FALLBACK_MODEL", llm_model)

    llm = ChatOpenAI(model=llm_model, temperature=0.2)
    slm = ChatOpenAI(model=slm_model, temperature=0.1)
    fallback = ChatOpenAI(model=fallback_model, temperature=0.2)
    return ModelBundle(slm=slm, llm=llm, fallback=fallback)

@retry(
    retry=retry_if_exception_type(Exception),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=0.5, min=0.5, max=4),
)
def invoke_with_retry(model, messages, trace_id: str, model_name: str):
    t0 = time.time()
    try:
        resp = model.invoke(messages)
        latency_ms = int((time.time() - t0) * 1000)

        usage = {}
        try:
            # langchain-openai typically exposes token usage in response_metadata
            usage = getattr(resp, 'response_metadata', {}).get('token_usage', {}) or {}
        except Exception:
            usage = {}

        record_metric('llm_call', {
            'trace_id': trace_id,
            'model': model_name,
            'latency_ms': latency_ms,
            'prompt_tokens': usage.get('prompt_tokens'),
            'completion_tokens': usage.get('completion_tokens'),
            'total_tokens': usage.get('total_tokens'),
        })

        log.info("llm_invoke_ok", extra={"trace_id": trace_id, "latency_ms": latency_ms, "model": model_name})
        return resp
    except Exception as e:
        latency_ms = int((time.time() - t0) * 1000)
        log.error(
            "llm_invoke_error",
            extra={"trace_id": trace_id, "latency_ms": latency_ms, "model": model_name, "error_type": type(e).__name__},
            exc_info=True,
        )
        raise

def invoke_with_fallback(primary, fallback, messages, trace_id: str, primary_name: str, fallback_name: str):
    try:
        return invoke_with_retry(primary, messages, trace_id, primary_name)
    except Exception:
        log.warning("llm_fallback", extra={"trace_id": trace_id, "model": fallback_name})
        return invoke_with_retry(fallback, messages, trace_id, fallback_name)
