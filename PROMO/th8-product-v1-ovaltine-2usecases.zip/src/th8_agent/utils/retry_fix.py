from typing import Any, Dict, Callable
from langchain_core.messages import SystemMessage, HumanMessage

def schema_fix_retry(llm, *, bad_output: str, schema_desc: str, trace_id: str):
    sys = SystemMessage(content=(
        "You must FIX the output to match the required schema exactly. "
        "Return STRICT JSON only. Do not add extra keys."
    ))
    human = HumanMessage(content=f"""
Bad output:
{bad_output}

Required schema:
{schema_desc}
""")
    return llm.invoke([sys, human])
