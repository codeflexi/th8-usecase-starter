from typing import Dict, Any
import json
from langchain_core.messages import SystemMessage, HumanMessage

from th8_agent.utils.llm_factory import invoke_with_fallback
from th8_agent.utils.schemas import DeviationClassification, json_loads
from th8_agent.utils.metrics import record_metric

def deviation_classifier(state: Dict[str, Any]) -> Dict[str, Any]:
    bundle = state["models"]
    trace_id = state["trace_id"]
    threshold = float(state.get("confidence_thresholds", {}).get("deviation_classify", 0.75))

    sys = SystemMessage(content=(
        "You classify manufacturing deviations. "
        "Return JSON only with keys: type, severity, confidence (0-1), rationale. "
        "Do not add extra keys."
    ))
    human = HumanMessage(content=f"""Deviation text:\n{state['payload']['text']}\n""")

    # 1) Try SLM first
    resp = invoke_with_fallback(
        primary=bundle["slm"],
        fallback=bundle["fallback"],
        messages=[sys, human],
        trace_id=trace_id,
        primary_name=state["model_names"]["slm"],
        fallback_name=state["model_names"]["fallback"],
    )

    raw = resp.content.strip()
    parsed = None
    try:
        obj = json_loads(raw)
        parsed = DeviationClassification.model_validate(obj)
    except Exception:
        parsed = None

    # 2) Confidence gate: escalate to LLM if low confidence or invalid schema
    if parsed is None or parsed.confidence < threshold:
        record_metric("confidence_escalation", {
            "trace_id": trace_id,
            "task_type": state.get("task_type"),
            "reason": "schema_invalid" if parsed is None else "low_confidence",
            "confidence": None if parsed is None else parsed.confidence,
            "threshold": threshold,
        })

        # Targeted schema-fix retry
        from th8_agent.utils.retry_fix import schema_fix_retry
        try:
            fixed = schema_fix_retry(bundle['llm'], bad_output=raw, schema_desc='type, severity, confidence (0-1), rationale', trace_id=trace_id)
            objf = json_loads(fixed.content)
            parsedf = DeviationClassification.model_validate(objf)
            return {'output': {'classification': parsedf.model_dump(), 'escalated': True, 'fix_retry': True}}
        except Exception:
            pass

        resp2 = invoke_with_fallback(
            primary=bundle["llm"],
            fallback=bundle["fallback"],
            messages=[sys, human],
            trace_id=trace_id,
            primary_name=state["model_names"]["llm"],
            fallback_name=state["model_names"]["fallback"],
        )
        raw2 = resp2.content.strip()
        try:
            obj2 = json_loads(raw2)
            parsed2 = DeviationClassification.model_validate(obj2)
            return {"output": {"classification": parsed2.model_dump(), "escalated": True}}
        except Exception:
            # last resort: return raw for investigation
            return {"output": {"classification_raw": raw2, "escalated": True, "schema_valid": False}}

    return {"output": {"classification": parsed.model_dump(), "escalated": False}}
