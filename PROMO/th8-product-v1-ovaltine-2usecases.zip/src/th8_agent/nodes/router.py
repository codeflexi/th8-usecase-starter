from typing import Dict, Any

ALIAS = {
    # New product tasks
    "complaint": "complaint_pipeline",
    "complaints": "complaint_pipeline",
    "consumer_care": "complaint_pipeline",
    "brand_protection": "complaint_pipeline",
    "fpa": "fpa_pipeline",
    "variance": "fpa_pipeline",
    "fpa_variance": "fpa_pipeline",
    # Keep old
    "qc": "qc_check",
    "sql": "batch_filter",
}

def route_task(state: Dict[str, Any]) -> Dict[str, Any]:
    t = (state.get("task_type") or "").strip()
    state["task_type"] = ALIAS.get(t, t)
    return state
