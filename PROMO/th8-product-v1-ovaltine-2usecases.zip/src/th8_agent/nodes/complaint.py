from typing import Dict, Any
from th8_agent.utils.pii import redact_payload
from th8_agent.utils.metrics import record_metric
from th8_agent.utils.tool_policy import assert_tool_allowed
from th8_agent.utils.sql import run_sql
from th8_agent.utils.schemas import ComplaintTriage, ComplaintEvidencePack
from th8_agent.utils.parsers import json_loads
from th8_agent.utils.retry_fix import schema_fix_retry

def _evidence_pack(state: Dict[str, Any]) -> ComplaintEvidencePack:
    payload = state.get("payload", {})
    complaint_id = payload.get("complaint_id", "C-NEW")
    product_code = payload.get("product_code", "OVALTIN-ORIGINAL")
    period = payload.get("period", "2025-12")

    assert_tool_allowed("complaint_pipeline", "sql")
    # Similar cases in last 90d (simplified for mock)
    q = """SELECT COUNT(*) as n FROM complaints WHERE product_code=?"""
    rows = run_sql(q, [product_code])
    n = int(rows[0]["n"]) if rows else 0

    # Top category proxy from keyword (mock)
    top_cat = "smell" if "กลิ่น" in (payload.get("text","") or "") else "other"

    return ComplaintEvidencePack(
        complaint_id=complaint_id,
        channel=payload.get("channel","unknown"),
        product_code=product_code,
        period=period,
        similar_cases_90d=n,
        top_similar_category=top_cat,
        notes="Evidence derived from complaints DB + policy pack (mock)."
    )

def complaint_pipeline(state: Dict[str, Any]) -> Dict[str, Any]:
    # Redact PII at payload-level as safety
    clean_payload, pii_audit = redact_payload(state.get("payload", {}))
    state["payload"] = clean_payload

    models = state["models"]
    slm = models["slm"]
    llm = models["llm"]

    text = clean_payload.get("text") or clean_payload.get("customer_text") or ""
    channel = clean_payload.get("channel") or "unknown"
    product_code = clean_payload.get("product_code") or "OVALTIN-ORIGINAL"
    complaint_id = clean_payload.get("complaint_id") or "C-NEW"
    period = clean_payload.get("period") or "2025-12"

    evidence = _evidence_pack({**state, "payload": {**clean_payload, "text": text, "channel": channel, "product_code": product_code, "period": period, "complaint_id": complaint_id}})

    prompt = [
        {"role":"system","content":(
            "You are a consumer-care triage agent for an FMCG brand. "
            "Return STRICT JSON only with keys: category, severity, confidence, rationale, recommended_action, pii_detected."
        )},
        {"role":"user","content":(
            f"Complaint (channel={channel}, product={product_code}):\n{text}\n\n"
            f"Evidence pack:\n{evidence.model_dump()}\n\n"
            "Guidance: health/alleged allergy -> higher severity and consider escalate_legal or escalate_qa. "
            "Packaging damage -> reply_standard/request_more_info. "
            "If confidence < 0.75, keep rationale concise."
        )}
    ]

    # SLM first
    t0 = record_metric("complaint_pipeline", "slm_start")
    resp = slm.invoke(prompt)
    record_metric("complaint_pipeline", "slm_end", extra={"latency_ms": t0()})

    raw = resp.content
    try:
        obj = json_loads(raw)
        triage = ComplaintTriage.model_validate(obj)
    except Exception:
        # targeted schema-fix retry with LLM
        t1 = record_metric("complaint_pipeline", "llm_fix_start")
        fixed = schema_fix_retry(llm, bad_output=raw, schema_desc="category, severity, confidence (0-1), rationale, recommended_action, pii_detected", trace_id="")
        record_metric("complaint_pipeline", "llm_fix_end", extra={"latency_ms": t1()})
        obj = json_loads(fixed.content)
        triage = ComplaintTriage.model_validate(obj)

    escalated = False
    if triage.confidence < 0.75 or triage.severity == "high":
        escalated = True
        # Escalate to LLM for a short manager-ready response
        prompt2 = [
            {"role":"system","content":"Write a short, professional response plan for consumer care and QA. Keep it under 7 bullet points."},
            {"role":"user","content":f"Triage: {triage.model_dump()}\nEvidence: {evidence.model_dump()}\nComplaint: {text}"}
        ]
        t2 = record_metric("complaint_pipeline", "llm_escalate_start")
        resp2 = llm.invoke(prompt2)
        record_metric("complaint_pipeline", "llm_escalate_end", extra={"latency_ms": t2()})
        manager_plan = resp2.content
    else:
        manager_plan = "No escalation required. Use standard reply + log case."

    return {
        "output": {
            "triage": triage.model_dump(),
            "evidence_pack": evidence.model_dump(),
            "manager_plan": manager_plan,
            "pii_audit": pii_audit,
            "escalated": escalated
        }
    }
