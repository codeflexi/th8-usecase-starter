from typing import Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage

from th8_agent.utils.llm_factory import invoke_with_fallback
from th8_agent.utils.schemas import RootCauseOutput, json_loads
from th8_agent.utils.metrics import record_metric

def root_cause_analysis(state: Dict[str, Any]) -> Dict[str, Any]:
    bundle = state["models"]
    trace_id = state["trace_id"]

    sys = SystemMessage(content=(
        "You are a senior manufacturing quality engineer. "
        "Analyze likely root causes and propose validation steps. "
        "Be explicit about uncertainty. "
        "Output STRICT JSON with keys: hypotheses (list of objects), checks (list of strings), immediate_actions (list of strings). "
        "No code fences."
    ))
    human = HumanMessage(content=f"""Incident context (JSON):\n{state['payload']}\n""")

    resp = invoke_with_fallback(
        primary=bundle["llm"],
        fallback=bundle["fallback"],
        messages=[sys, human],
        trace_id=trace_id,
        primary_name=state["model_names"]["llm"],
        fallback_name=state["model_names"]["fallback"],
    )
    raw = (resp.content or "").strip()

    try:
        obj = json_loads(raw)
        parsed = RootCauseOutput.model_validate(obj)
        return {"output": {"analysis": parsed.model_dump(), "schema_valid": True}}
    except Exception:
        record_metric("schema_invalid", {"trace_id": trace_id, "task_type": state.get("task_type")})
        return {"output": {"analysis_raw": raw, "schema_valid": False}}
