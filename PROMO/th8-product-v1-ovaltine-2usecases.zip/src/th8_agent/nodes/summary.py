from typing import Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage

from th8_agent.utils.llm_factory import invoke_with_fallback
from th8_agent.utils.schemas import ExecSummaryOutput
from th8_agent.utils.metrics import record_metric

def exec_summary(state: Dict[str, Any]) -> Dict[str, Any]:
    bundle = state["models"]
    trace_id = state["trace_id"]

    sys = SystemMessage(content=(
        "You are an operations analytics assistant for a manufacturing plant. "
        "Return a concise executive summary. "
        "Format strictly as plain text with three sections:\n"
        "1) Key facts\n2) Risks\n3) Recommended actions (next 7 days)\n"
        "Keep it under 1800 characters."
    ))
    human = HumanMessage(content=f"""Data snapshot (JSON):\n{state['payload']['data']}\n""")

    # SLM first
    resp = invoke_with_fallback(
        primary=bundle["slm"],
        fallback=bundle["fallback"],
        messages=[sys, human],
        trace_id=trace_id,
        primary_name=state["model_names"]["slm"],
        fallback_name=state["model_names"]["fallback"],
    )
    text = (resp.content or "").strip()

    # Schema validation: minimal but enforce non-empty and size
    ok = True
    if not text or len(text) > 1800:
        ok = False

    if not ok:
        record_metric("schema_escalation", {
            "trace_id": trace_id,
            "task_type": state.get("task_type"),
            "reason": "empty_or_too_long",
            "length": len(text),
        })
        resp2 = invoke_with_fallback(
            primary=bundle["llm"],
            fallback=bundle["fallback"],
            messages=[sys, human],
            trace_id=trace_id,
            primary_name=state["model_names"]["llm"],
            fallback_name=state["model_names"]["fallback"],
        )
        text2 = (resp2.content or "").strip()
        return {"output": {"summary": text2, "escalated": True}}

    # keep consistent output contract
    out = ExecSummaryOutput(summary=text)
    return {"output": {"summary": out.summary, "escalated": False}}
