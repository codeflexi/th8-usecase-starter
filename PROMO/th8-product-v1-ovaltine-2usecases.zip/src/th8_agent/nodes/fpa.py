from typing import Dict, Any, List
from th8_agent.utils.schemas import FPAVarianceExplain, ExecutiveBrief
from th8_agent.utils.parsers import json_loads
from th8_agent.utils.retry_fix import schema_fix_retry
from th8_agent.utils.tool_policy import assert_tool_allowed
from th8_agent.utils.sql import run_sql
from th8_agent.utils.metrics import record_metric

def _fetch_plan_actual(period: str, metric: str):
    assert_tool_allowed("fpa_pipeline", "sql")
    q = "SELECT plan_value, actual_value FROM fpa_plan_actual WHERE period=? AND metric=?"
    rows = run_sql(q, [period, metric])
    if not rows:
        return None
    return float(rows[0]["plan_value"]), float(rows[0]["actual_value"])

def _fetch_promos(period: str):
    assert_tool_allowed("fpa_pipeline", "sql")
    q = "SELECT promo_id, channel, promo_type, expected_uplift_pct, notes FROM promo_calendar WHERE period=?"
    return run_sql(q, [period])

def fpa_pipeline(state: Dict[str, Any]) -> Dict[str, Any]:
    payload = state.get("payload", {})
    period = payload.get("period", "2025-11")
    metric = payload.get("metric", "net_sales")

    models = state["models"]
    slm = models["slm"]
    llm = models["llm"]

    pa = _fetch_plan_actual(period, metric)
    if not pa:
        return {"output": {"error": f"No plan/actual for period={period}, metric={metric}"}}
    plan, actual = pa
    var_val = actual - plan
    var_pct = (var_val / plan) * 100.0 if plan else 0.0

    promos = _fetch_promos(period)

    prompt = [
        {"role":"system","content":(
            "You are an FP&A variance explanation agent for an FMCG company. "
            "Return STRICT JSON only with keys: period, metric, variance_value, variance_pct, drivers, recommended_actions, confidence."
        )},
        {"role":"user","content":(
            f"Period: {period}\nMetric: {metric}\nPlan: {plan}\nActual: {actual}\nVariance: {var_val} ({var_pct:.2f}%)\n\n"
            f"Promo calendar signals: {promos}\n\n"
            "Drivers must be a list of {driver,evidence}. Actions must be a list of {action,owner,due}. "
            "Keep it realistic for Thai enterprise. If uncertain, set confidence < 0.75."
        )}
    ]

    # SLM first for structured output
    t0 = record_metric("fpa_pipeline", "slm_start")
    resp = slm.invoke(prompt)
    record_metric("fpa_pipeline", "slm_end", extra={"latency_ms": t0()})
    raw = resp.content
    try:
        obj = json_loads(raw)
        explain = FPAVarianceExplain.model_validate(obj)
    except Exception:
        t1 = record_metric("fpa_pipeline", "llm_fix_start")
        fixed = schema_fix_retry(llm, bad_output=raw, schema_desc="period, metric, variance_value, variance_pct, drivers[{driver,evidence}], recommended_actions[{action,owner,due}], confidence", trace_id="")
        record_metric("fpa_pipeline", "llm_fix_end", extra={"latency_ms": t1()})
        obj = json_loads(fixed.content)
        explain = FPAVarianceExplain.model_validate(obj)

    # Escalate for executive brief when confidence low or big variance
    need_exec = explain.confidence < 0.75 or abs(explain.variance_pct) >= 5.0
    if need_exec:
        prompt2 = [
            {"role":"system","content":(
                "Create an executive briefing in Thai. "
                "Return STRICT JSON with keys: period, key_points[], risks[], actions_next_7d[]"
            )},
            {"role":"user","content":f"Explain: {explain.model_dump()}\nPromo signals: {promos}\nWrite for CFO/COO; concise and actionable."}
        ]
        t2 = record_metric("fpa_pipeline", "llm_exec_start")
        resp2 = llm.invoke(prompt2)
        record_metric("fpa_pipeline", "llm_exec_end", extra={"latency_ms": t2()})
        raw2 = resp2.content
        try:
            obj2 = json_loads(raw2)
            brief = ExecutiveBrief.model_validate(obj2)
        except Exception:
            fixed2 = schema_fix_retry(llm, bad_output=raw2, schema_desc="period, key_points[], risks[], actions_next_7d[]", trace_id="")
            obj2 = json_loads(fixed2.content)
            brief = ExecutiveBrief.model_validate(obj2)
    else:
        brief = ExecutiveBrief(period=period, key_points=["Variance within tolerance."], risks=[], actions_next_7d=[])

    return {"output": {"variance_explain": explain.model_dump(), "executive_brief": brief.model_dump(), "promo_signals": promos}}
