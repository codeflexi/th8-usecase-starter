from typing import Dict, Any

def qc_spec_check(state: Dict[str, Any]) -> Dict[str, Any]:
    moisture = float(state["payload"]["moisture"])
    spec_limit = float(state["payload"]["spec_limit"])
    if moisture > spec_limit:
        return {"output": {"result": "FAIL", "reason": f"Moisture {moisture}% exceeds spec {spec_limit}%"}}
    return {"output": {"result": "PASS", "reason": "Within specification"}}
