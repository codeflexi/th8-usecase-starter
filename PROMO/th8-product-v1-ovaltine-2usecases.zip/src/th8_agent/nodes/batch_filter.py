from typing import Dict, Any
from th8_agent.utils.sql import run_sql

def batch_filter(state: Dict[str, Any]) -> Dict[str, Any]:
    days = int(state["payload"].get("days", 30))
    yield_lt = float(state["payload"].get("yield_lt", 95.0))
    query = """
    SELECT batch_id, date, yield_pct, moisture, qc_status, supplier, line
    FROM batches
    WHERE date >= date('now', ?)
      AND yield_pct < ?
    ORDER BY date DESC
    LIMIT 50;
    """
    params = (f"-{days} day", yield_lt)
    res = run_sql(query, params, task_type=state.get("task_type"))
    return {"output": {"criteria": {"days": days, "yield_lt": yield_lt}, **res}}
