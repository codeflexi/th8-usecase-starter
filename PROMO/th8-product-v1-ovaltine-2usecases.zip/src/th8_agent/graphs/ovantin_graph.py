import logging
from typing import Any, Dict, Literal, TypedDict

from langgraph.graph import StateGraph, END

from th8_agent.nodes.qc import qc_spec_check
from th8_agent.nodes.batch_filter import batch_filter
from th8_agent.nodes.root_cause import root_cause_analysis
from th8_agent.nodes.summary import exec_summary
from th8_agent.nodes.classifier import deviation_classifier
from th8_agent.utils.logging import new_trace_id

log = logging.getLogger("th8.graph")

TaskType = Literal["qc_check", "batch_filter", "root_cause", "exec_summary", "deviation_classify"]

class AgentState(TypedDict, total=False):
    task_type: TaskType
    payload: Dict[str, Any]
    output: Dict[str, Any]
    trace_id: str
    models: Dict[str, Any]
    model_names: Dict[str, str]
    confidence_thresholds: Dict[str, Any]

def init_state(state: AgentState) -> AgentState:
    if not state.get("trace_id"):
        state["trace_id"] = new_trace_id()
    # Default confidence thresholds (tune per client)
    if not state.get('confidence_thresholds'):
        state['confidence_thresholds'] = {
            'deviation_classify': 0.75,
        }
    return state

def router(state: AgentState) -> str:
    tt = state["task_type"]
    if tt in ("qc_check", "batch_filter"):
        return tt
    if tt in ("root_cause", "exec_summary", "deviation_classify"):
        return tt
    return "exec_summary"

def build_graph():
    g = StateGraph(AgentState)
    g.add_node("init", init_state)
    g.add_node("qc_check", qc_spec_check)
    g.add_node("batch_filter", batch_filter)
    g.add_node("root_cause", root_cause_analysis)
    g.add_node("exec_summary", exec_summary)
    g.add_node("deviation_classify", deviation_classifier)

    g.set_entry_point("init")
    g.add_conditional_edges("init", router, {
        "qc_check": "qc_check",
        "batch_filter": "batch_filter",
        "root_cause": "root_cause",
        "exec_summary": "exec_summary",
        "deviation_classify": "deviation_classify",
    })

    for n in ["qc_check", "batch_filter", "root_cause", "exec_summary", "deviation_classify"]:
        g.add_edge(n, END)

    return g.compile()
