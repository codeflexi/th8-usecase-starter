from langgraph.graph import StateGraph, END
from typing import TypedDict, Dict, Any

from th8_agent.nodes.router import route_task
from th8_agent.nodes.complaint import complaint_pipeline
from th8_agent.nodes.fpa import fpa_pipeline
from th8_agent.nodes.summary import exec_summary
from th8_agent.nodes.classifier import deviation_classify
from th8_agent.nodes.root_cause import root_cause
from th8_agent.nodes.qc import qc_check
from th8_agent.nodes.sql_agent import batch_filter

class AgentState(TypedDict, total=False):
    task_type: str
    payload: Dict[str, Any]
    models: Dict[str, Any]
    model_names: Dict[str, str]
    output: Dict[str, Any]

def build_graph():
    g = StateGraph(AgentState)

    g.add_node("route", route_task)

    # Existing demo nodes
    g.add_node("qc_check", qc_check)
    g.add_node("batch_filter", batch_filter)
    g.add_node("deviation_classify", deviation_classify)
    g.add_node("root_cause", root_cause)
    g.add_node("exec_summary", exec_summary)

    # New product nodes
    g.add_node("complaint_pipeline", complaint_pipeline)
    g.add_node("fpa_pipeline", fpa_pipeline)

    g.set_entry_point("route")

    # Route
    g.add_conditional_edges("route", lambda s: s["task_type"], {
        # Existing tasks
        "qc_check": "qc_check",
        "batch_filter": "batch_filter",
        "deviation_classify": "deviation_classify",
        "root_cause": "root_cause",
        "exec_summary": "exec_summary",
        # New tasks
        "complaint_pipeline": "complaint_pipeline",
        "fpa_pipeline": "fpa_pipeline",
    })

    for node in ["qc_check","batch_filter","deviation_classify","root_cause","exec_summary","complaint_pipeline","fpa_pipeline"]:
        g.add_edge(node, END)

    return g.compile()
