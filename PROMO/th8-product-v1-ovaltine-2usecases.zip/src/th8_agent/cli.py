import argparse
import json
import os
from dotenv import load_dotenv

from th8_agent.utils.logging import setup_logging
from th8_agent.utils.llm_factory import build_models
from th8_agent.utils.sql import run_sql
from th8_agent.graphs.ovantin_graph import build_graph

def main():
    load_dotenv()
    setup_logging()

    parser = argparse.ArgumentParser()
    parser.add_argument("--task", required=True, choices=["qc_check","batch_filter","root_cause","exec_summary","deviation_classify"])
    parser.add_argument("--moisture", type=float)
    parser.add_argument("--spec_limit", type=float)
    parser.add_argument("--yield_lt", type=float, default=95.0)
    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--batch_id", type=str)
    parser.add_argument("--text", type=str)
    args = parser.parse_args()

    models = build_models()
    graph = build_graph()

    model_dict = {"slm": models.slm, "llm": models.llm, "fallback": models.fallback}
    model_names = {
        "slm": os.getenv("SLM_MODEL", os.getenv("LLM_MODEL", "gpt-4o-mini")),
        "llm": os.getenv("LLM_MODEL", "gpt-4o-mini"),
        "fallback": os.getenv("FALLBACK_MODEL", os.getenv("LLM_MODEL", "gpt-4o-mini")),
    }

    if args.task == "qc_check":
        payload = {"moisture": args.moisture, "spec_limit": args.spec_limit}
    elif args.task == "batch_filter":
        payload = {"yield_lt": args.yield_lt, "days": args.days}
    elif args.task == "root_cause":
        ctx = {"batch_id": args.batch_id}
        if args.batch_id:
            res = run_sql("SELECT * FROM batches WHERE batch_id = ? LIMIT 1;", (args.batch_id,), task_type=args.task)
            ctx["batch"] = res["rows"][0] if res["rows"] else None
            dev = run_sql("SELECT * FROM deviations WHERE batch_id = ? ORDER BY date DESC LIMIT 5;", (args.batch_id,), task_type=args.task)
            ctx["recent_deviations"] = dev["rows"]
        payload = ctx
    elif args.task == "exec_summary":
        fails = run_sql("SELECT COUNT(*) AS fail_count FROM batches WHERE qc_status='FAIL' AND date >= date('now', ?);", (f"-{args.days} day",), task_type=args.task)
        low_yield = run_sql("SELECT COUNT(*) AS low_yield_count FROM batches WHERE yield_pct < 95 AND date >= date('now', ?);", (f"-{args.days} day",), task_type=args.task)
        top = run_sql("SELECT supplier, COUNT(*) as c FROM batches WHERE date >= date('now', ?) GROUP BY supplier ORDER BY c DESC;", (f"-{args.days} day",), task_type=args.task)
        payload = {"data": {"window_days": args.days, "qc_fail": fails["rows"][0], "low_yield": low_yield["rows"][0], "by_supplier": top["rows"]}}
    else:
        payload = {"text": args.text or "Moisture out of spec after supplier change"}

    state = {
        "task_type": args.task,
        "payload": payload,
        "models": model_dict,
        "model_names": model_names,
    }

    out = graph.invoke(state)
    print(json.dumps(out.get("output", out), ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
