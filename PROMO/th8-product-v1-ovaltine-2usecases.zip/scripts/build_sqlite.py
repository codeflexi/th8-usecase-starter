import sqlite3
from pathlib import Path

DB_PATH = Path("data/mock.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def main():
    if DB_PATH.exists():
        DB_PATH.unlink()

    con = sqlite3.connect(DB_PATH.as_posix())
    cur = con.cursor()

    # -----------------------------
    # Existing demo tables
    # -----------------------------
    cur.execute("""CREATE TABLE qc_batches (
        batch_id TEXT PRIMARY KEY,
        product_code TEXT,
        moisture REAL,
        yield_pct REAL,
        qc_status TEXT,
        event_time TEXT,
        line_id TEXT
    )""")

    cur.execute("""INSERT INTO qc_batches VALUES
        ('OVT-2512-05','OVALTIN-ORIGINAL',4.2,93.8,'FAIL','2025-12-18T09:32:00Z','LINE-2'),
        ('OVT-2512-04','OVALTIN-ORIGINAL',3.8,95.5,'PASS','2025-12-17T09:30:00Z','LINE-2'),
        ('OVT-2512-03','OVALTIN-ORIGINAL',4.1,94.6,'FAIL','2025-12-16T09:25:00Z','LINE-1')
    """)

    # -----------------------------
    # New product tables: complaints
    # -----------------------------
    cur.execute("""CREATE TABLE complaints (
        complaint_id TEXT PRIMARY KEY,
        created_at TEXT,
        channel TEXT,
        customer_text TEXT,
        product_code TEXT,
        lot_hint TEXT,
        province TEXT
    )""")

    cur.execute("""INSERT INTO complaints VALUES
        ('C-0001','2025-12-20T10:05:00Z','Facebook','กลิ่นแปลก เหมือนหืน เปิดแล้วไม่มั่นใจให้ลูกดื่ม','OVALTIN-ORIGINAL','OVT-2512-05','Bangkok'),
        ('C-0002','2025-12-19T09:12:00Z','LINE OA','กล่องบุบตอนถึงบ้าน และผงจับตัวเป็นก้อน','OVALTIN-ORIGINAL','OVT-2512-04','Nonthaburi'),
        ('C-0003','2025-11-28T14:22:00Z','Call Center','รสชาติเปลี่ยนไปจากเดิม ซื้อที่โลตัส','OVALTIN-ORIGINAL','OVT-2511-12','Chiang Mai'),
        ('C-0004','2025-11-12T08:55:00Z','Modern Trade','ลูกค้าร้องเรียนเรื่องอาการแพ้ ต้องการให้ตรวจสอบด่วน','OVALTIN-ORIGINAL','OVT-2511-02','Bangkok')
    """)

    # -----------------------------
    # New product tables: finance
    # -----------------------------
    cur.execute("""CREATE TABLE fpa_plan_actual (
        period TEXT,
        metric TEXT,
        plan_value REAL,
        actual_value REAL,
        PRIMARY KEY (period, metric)
    )""")

    cur.execute("""INSERT INTO fpa_plan_actual VALUES
        ('2025-11','net_sales', 120000000, 112000000),
        ('2025-11','volume',    980000,    915000),
        ('2025-11','cogs',      72000000,  74500000),
        ('2025-11','gross_margin', 48000000, 37500000),
        ('2025-12','net_sales', 130000000, 128500000),
        ('2025-12','volume',    1020000,   1012000),
        ('2025-12','cogs',      78000000,  78200000),
        ('2025-12','gross_margin', 52000000, 50300000)
    """)

    cur.execute("""CREATE TABLE promo_calendar (
        promo_id TEXT PRIMARY KEY,
        period TEXT,
        channel TEXT,
        promo_type TEXT,
        expected_uplift_pct REAL,
        notes TEXT
    )""")

    cur.execute("""INSERT INTO promo_calendar VALUES
        ('P-1101','2025-11','Modern Trade','price_cut', 18.0,'โปรลดราคา 2 สัปดาห์'),
        ('P-1102','2025-11','E-commerce','bundle',    10.0,'bundle + free shipping'),
        ('P-1201','2025-12','Modern Trade','display',   6.0,'ปลายปี เพิ่ม display')
    """)

    con.commit()
    con.close()
    print(f"Built {DB_PATH}")

if __name__ == '__main__':
    main()
