# TH8 Product v1 — Ovaltine Agents (2 Use Cases)

This repo packages **two sellable enterprise-ready agentic use cases** into a single FastAPI + LangGraph project:

1) **Customer Complaint & Brand Protection Agent**
- Classify complaint, risk score, recommend escalation (QA/Legal), generate manager plan
- Includes **PII redaction + field-level audit**

2) **FP&A Variance Explanation & Executive Briefing Agent**
- Explain Plan vs Actual variance with evidence signals (promo calendar), propose actions
- Produces structured outputs + executive brief (Thai)

Both use cases share a **governed agentic architecture**:
- SLM-first with LLM escalation
- Confidence gate + schema validation
- Targeted output re-try (schema-fix)
- Tool permission (allow-list)
- Metrics/cost tracking (jsonl)

---

## 1) Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/build_sqlite.py
```

Set models in `.env` (or environment variables). Example:

```bash
SLM_MODEL=...
LLM_MODEL=...
FALLBACK_MODEL=...
```

## 2) Run API

```bash
uvicorn th8_agent.api:app --reload --port 8000
```

Open:
- UI mockups: http://localhost:8000/ui/index.html
- API docs: http://localhost:8000/docs

## 3) Test (Postman)

Import `postman_collection.json` and run:
- Demo: Get Complaint Payload
- Run: Complaint Pipeline
- Demo: Get FP&A Payload
- Run: FP&A Pipeline

---

## 4) Core Endpoints

- `POST /run`  (single entry point)
- `GET /demo/complaint`
- `GET /demo/fpa`

Request format:

```json
{
  "task_type": "complaint_pipeline",
  "payload": { "text": "...", "channel": "Facebook", "product_code": "OVALTIN-ORIGINAL" }
}
```

---

## 5) Where to extend for production

- Replace sqlite with your enterprise data sources (ERP/DWH/CRM/Contact center)
- Add role-based access control + tenant isolation
- Replace toy PII patterns with enterprise-grade redaction (DLP + regex + NER)
- Push metrics to Prometheus / OpenTelemetry
